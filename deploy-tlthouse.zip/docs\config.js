﻿// Заполните owner после создания репозитория, например: 'ivanchev'
window.TLT_GH = {
  owner: 'tlthouse',
  repo: 'tlthouse.github.io',
  branch: 'main'
};

