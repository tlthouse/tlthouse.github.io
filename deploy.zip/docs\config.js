// Заполните owner после создания репозитория, например: 'ivanchev'
window.TLT_GH = {
  owner: '',
  repo: 'tlt-house',
  branch: 'main'
};
